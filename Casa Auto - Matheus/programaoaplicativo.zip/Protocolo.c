/* 
 * Arquivo: Protocolo.h
 * Autor:   JABNeto
 * Data:    02.06.2017
 */


#include "Protocolo.h"
#include "Controle de cargas.h"
#include "Controle do motor.h"



//Aloca��o de memoria para o m�dulo -------------------------------------------
StrFrameTx  Tx;
StrFrameRx  Rx;
StrCtrlTxRx CtrlTx;
StrCtrlTxRx CtrlRx;


//Fun��es locais --------------------------------------------------------------
void Protocolo_ResetaRx (void);
void Protocolo_ExecutaComandosRx(void);




//Fun��es publicas ------------------------------------------------------------
void Protocolo_Inicializacao (void)
{
    CtrlTx.Pnt = 0;
    CtrlTx.Sequencia = 0;
    
    Protocolo_ResetaRx();
}


/*
 * Protocolo_ResetaRx
 * Resseta a recep��o do frame Rx
 */
void Protocolo_ResetaRx (void)
{
    CtrlRx.Pnt = 0;
    CtrlRx.Sequencia = 0; 
}

/*
 * Protocolo_Rx
 * Recebe dados pela unidade serial e interpreta comandos
 */
void Protocolo_Rx (Uchar ByteRecebido)
{
    switch (CtrlRx.Sequencia)
    {
        case 0:
            if (ByteRecebido == Protocolo_CaractereSincronismo1) CtrlRx.Sequencia++;
            else Protocolo_ResetaRx();
            break;
        
        case 1:
            if (ByteRecebido == Protocolo_CaractereSincronismo2) CtrlRx.Sequencia++;
            else Protocolo_ResetaRx();
            break;        
        
        case 2:
            if (ByteRecebido == Protocolo_CaractereSincronismo3) CtrlRx.Sequencia++;
            else Protocolo_ResetaRx();            
            break;        
        
        case 3:
            if (ByteRecebido == Protocolo_CaractereSincronismo4) CtrlRx.Sequencia++;
            else Protocolo_ResetaRx();            
            break;
  
        case 4:
            Rx.Frame.Campos.Header.Comando = ByteRecebido;
            CtrlRx.Sequencia++;
            break;            

        case 5:
            Rx.Frame.Campos.Dados[0]= ByteRecebido;
            CtrlRx.Sequencia++;
            break;

        case 6:
            Rx.Frame.Campos.Dados[1]= ByteRecebido;
            CtrlRx.Sequencia++;
            break;
            
        case 7:
            if (ByteRecebido == Protocolo_CaractereEndFrame)
            {
                Protocolo_ResetaRx();
                
                Rx.Frame.Campos.Header.Comando -= 0x30;
                Protocolo_ExecutaComandosRx();                
            }
            else Protocolo_ResetaRx();
            break; 
    }
}


Uchar RetornaNumeroDaSaida (void)
{
    Uchar Saida;
    
    Saida = (Rx.Frame.Campos.Dados[0] - 0x30) * 10 + (Rx.Frame.Campos.Dados[1]-0x30);  
    return Saida;
}




/*
 * Protocolo_ExecutaComandosRx
 * Recebe dados pela unidade serial e interpreta comandos
 */
void Protocolo_ExecutaComandosRx(void)
{
    switch (Rx.Frame.Campos.Header.Comando)
    {
        case 1:
            LigaSaida(RetornaNumeroDaSaida());
            break;
 
        case 2:
            DesligaSaida(RetornaNumeroDaSaida());
            break;       

        case 3:
           DesligaSaidas();
           break;
           
        case 4:
            CtrlMotor.Sinais.PedidoAbertura = Sim;
           break;
                      
        case 5:
            CtrlMotor.Sinais.PedidoFechamento = Sim;
           break;  

        case 6:
           CtrlMotor.Sinais.PedidoParar = Sim;
           break;             
    }
}


