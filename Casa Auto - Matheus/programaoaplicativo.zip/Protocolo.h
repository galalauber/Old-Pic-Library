/* 
 * Arquivo: Protocolo.h
 * Autor:   JABNeto
 * Data:    02.06.2017
 */

#ifndef PROTOCOLO_H
#define	PROTOCOLO_H

#include "Definicoes Gerais.h"


//Defini��es do modulo -------------------------------------------------------
#define Protocolo_NbytesHeader                      5
#define Protocolo_NbytesDadosTx                     16
#define Protocolo_NbytesDadosRx                     16
#define Protocolo_NbytesEndFrame                    1

#define Protocolo_CaractereSincronismo1             '#'
#define Protocolo_CaractereSincronismo2             'S'
#define Protocolo_CaractereSincronismo3             'T'
#define Protocolo_CaractereSincronismo4             '#'
#define Protocolo_CaractereEndFrame                 '*'


#define Protocolo_TamanhoBufferTx   (Protocolo_NbytesHeader + Protocolo_NbytesDadosTx + Protocolo_NbytesEndFrame)
#define Protocolo_TamanhoBufferRx   (Protocolo_NbytesHeader + Protocolo_NbytesDadosRx + Protocolo_NbytesEndFrame)




//Estruturas do m�dulo -------------------------------------------------------
typedef struct
{
    Uchar Sequencia;
    Uchar Pnt;
}StrCtrlTxRx;

typedef struct
{
    Uchar Sincronismo[4];
    Uchar Comando;
}StrHeader;

typedef struct
{
    union
    {
        Uchar   Buffer[Protocolo_TamanhoBufferRx - 1];
        
        struct
        {
            StrHeader   Header;
            Uchar       Dados[Protocolo_NbytesDadosRx - 1];
        }Campos;
    }Frame;
 }StrFrameRx;

 

typedef struct
{
    union
    {
        Uchar   Buffer[Protocolo_TamanhoBufferTx - 1];
        
        struct
        {
            StrHeader   Header;
            Uchar       Dados[Protocolo_NbytesDadosTx - 1];
        }Campos;
    }Frame;
}StrFrameTx;


//Publica��o das fun��es do m�dulo -------------------------------------------
void Protocolo_Inicializacao (void);
void Protocolo_Rx (Uchar ByteRecebido);


#endif	/* PROTOCOLO_H */

