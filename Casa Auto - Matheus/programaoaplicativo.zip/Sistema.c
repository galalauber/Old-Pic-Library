/* 
 *  Arquivo:    Sistema.c
 *  Autor:      JABNeto
 *  Vers�o:     161011 
 */


#include <xc.h>
#include "App.h"
#include "Sistema.h"
#include "Cpu.h"

//Fun��es locais do modulo ----------------------------------------------------

/*
 * Sistema_Inicializacao
 * Faz a inicializacao do sistema
 */
void Sistema_Inicializacao (void)
{
    Cpu_Inicializacao();
    App_Inicializacao();
    Cpu_InicializaInterrupcoes();
}


/*
 *  main()
 *  Fun��o principal do sistema
 */
void main(void)
{
    Sistema_Inicializacao();
    
    while(1)
    {
        App_Monitor();
    }
}



















