/* 
 *  Arquivo:    Sistema.h
 *  Autor:      JABNeto
 *  Vers�o:     161011 
 */

#ifndef SISTEMA_H
#define	SISTEMA_H





//Publica��o das fun��es do m�dulo -------------------------------------------





#endif	/* SISTEMA_H */

