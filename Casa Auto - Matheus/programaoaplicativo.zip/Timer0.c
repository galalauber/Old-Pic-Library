/* 
 * Arquivo: Timer 0.c
 * uC:      PIC18F46K20
 * Autor:   JABNeto
 * Data:    06.03.2017
 */


#include "Timer0.h"


//Aloca��o de mem�ria para o m�dulo -------------------------------------------
_Timer0 Timer0;



//Fun��es locais --------------------------------------------------------------





//Fun��es p�blicas ------------------------------------------------------------
/*
 * Timer0_Inicializacao()
 * Faz a inicializa��o do m�dulo Timer 0
 */
void Timer0_Inicializacao (void)
{
    Timer0_CarregaValor();

    Timer0.ContadorDe10ms = 10;
    Timer0.ContadorDe100ms = 100;
    
    //T0CON
    T0CONbits.T08BIT = TIMER0_16BITS;
    T0CONbits.T0CS = TIMER0_FOP;
    T0CONbits.PSA = TIMER0_PSA;
    T0CONbits.T0PS = T0CKPS_16;
    
    #if (Timer0_UsaInterrupcoes() == Sim)
        TMR0IE = Sim;        
    #endif

    Timer0_LigaModulo();    
}


/*
 * Timer0_CarregaValor
 * Carrega os registradores de contagem temporizador
 */
void Timer0_CarregaValor(void)
{
    Uint16 ValorDeCarga;
    
    ValorDeCarga.valor = (Uint)Timer0_ValorDeCarga();
    
    TMR0H = ValorDeCarga.bytes.byte1;
    TMR0L = ValorDeCarga.bytes.byte0;
}

#if (Timer0_UsaInterrupcoes() == Sim)
/*
 * Timer0_ServicoDeInterrupcao
 * Executa o servi�o de interrup��o do modulo
 */
void Timer0_ServicoDeInterrupcao (void)
{
    if (TMR0IE && TMR0IF)
    {
       TMR0IF = 0; 
       Timer0_CarregaValor();

       
       //Tarefas de 1ms

       
       
       
       //Temporizador de 10ms
       if (--Timer0.ContadorDe10ms == 0)
       {
           Timer0.ContadorDe10ms = 10;
           
           //Tarefas de 10ms via interrup��o
           
           
       }
       
       //Temporizador de 100ms
       if (--Timer0.ContadorDe100ms == 0)
       {
           Timer0.ContadorDe100ms = 100;
           
           //Tarefas de 100ms via interrup��o           

       }       
    }
}
#endif









