/* 
 * Arquivo: Timer0.h
 * uC:      PIC18F46K22
 * Autor:   JABNeto
 * Data:    06.03.2017
 */

#ifndef TIMER0_H
#define	TIMER0_H

#include <xc.h>
#include "Definicoes Gerais.h"
#include "Oscilador.h"


//Defini��es do m�dulo --------------------------------------------------------

//T0EN - Ativa/Desativa o modulo
#define TIMER_DISABLE                           0
#define TIMER_ENABLE                            1


//T08BIT: Modo de opera��o: 8/16 bits
#define TIMER0_8BITS                            0
#define TIMER0_16BITS                           1

//T0CS: Fonte de clock
#define TIMER0_FOP                              0
#define TIMER0_T0CKI                            1


//T0SE: Incremento na Transi��o positiva
//      ou negativa quando no modo contador
#define TIMER0_TPOS                              0
#define TIMER0_TNEG                              1


//PSA:  Habilita o uso do Prescaler para a
//      divisao do sinal de clock
#define TIMER0_PSA                              0
#define TIMER0_NPSA                             1


//T0CKPS - Fator de divis�o do prescaler
#define T0CKPS_2                                0
#define T0CKPS_4                                1
#define T0CKPS_8                                2
#define T0CKPS_16                               3
#define T0CKPS_32                               4
#define T0CKPS_64                               5
#define T0CKPS_128                              6
#define T0CKPS_256                              7



//Configura��es do m�dulo -----------------------------------------------------


//Configura��o do modulo para gerar eventos de interrup��o a cada 1ms
#define TIMER0_T0CS                                     TIMER0_FOP
#define TIMER0_PRESCALER                                TIMER0_16BITS 

#define Timer0_Fclkin()                                 Fop()
#define Timer0_ValorDoPrescaler()                       16
#define Timer0_Tempo_ms()                               1e-3
#define Timer0_UsaInterrupcoes()                        Sim
#define Timer0_PrioridadeDasInterrupcoes()              Alta


//Macros do modulo ------------------------------------------------------------
#define Timer0_LigaModulo()                             {T0CONbits.TMR0ON = 1;}
#define Timer0_DesligaModulo()                          {T0CONbits.TMR0ON = 0;}


//Pr�-processamento -----------------------------------------------------------
/*
 * C�clulo do valor de carga do temporizador 
 * TMR0 = 65536 - ((Tempo * Fckin)/(Prescaler * Postscaler))
 * 
 *  Ex. Tempo: 1.0ms, Fckin = 8.0MHz, Prescaler = 16, Postscaler = 1)
 * 
 *  TMR0 = 65536 - ((1.0e-3 * 8.0e6)/(16 * 1))
 *  TMR0 = 65536 - 500
 *  TMR0 = 65036 = (FE0C)
 */
#define Timer0_ValorDeCarga()  (65535 - ((Timer0_Tempo_ms() * Timer0_Fclkin())/ (Timer0_ValorDoPrescaler())))


//Interrup��es do m�dulo
#if (Timer0_UsaInterrupcoes() == Sim)
    #if ( Timer0_PrioridadeDasInterrupcoes() == Alta)
        #ifndef Cpu_UsaInterrupcoesDeAltaPrioridade
        #define Cpu_UsaInterrupcoesDeAltaPrioridade()
        #endif
    #else
        #ifndef Cpu_UsaInterrupcoesDeBaixaPrioridade
        #define Cpu_UsaInterrupcoesDeBaixaPrioridade()
        #endif
    #endif
#endif


//Estruturas do m�dulo --------------------------------------------------------
typedef struct
{
    Uchar   ContadorDe10ms;    
    Uchar   ContadorDe100ms;
}_Timer0;



    
//Publica��o das fun��es do m�dulo --------------------------------------------
void Timer0_Inicializacao (void);
void Timer0_CarregaValor(void);

#if (Timer0_UsaInterrupcoes() == Sim)
void Timer0_ServicoDeInterrupcao (void);
#endif 


//Publica��o das vari�veis do m�dulo ------------------------------------------



#endif	/* TIMER0_H */

