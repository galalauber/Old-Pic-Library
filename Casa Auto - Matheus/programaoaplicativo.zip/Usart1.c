/* 
 * Arquivo: Usart1.c
 * uC:      PIC18F46K22
 * Autor:   JABNeto
 * Data:    06.03.2017
 */

#include <xc.h>
#include "Usart1.h"


//Aloca��o de memoria para o m�dulo -------------------------------------------
StrFrameTx  Tx;
StrFrameRx  Rx;


//Fun��es locais --------------------------------------------------------------





//Fun��es publicas ------------------------------------------------------------
void Usart1_Inicializacao (void)
{
    Uint16 BaudRate;
  
    TRISCbits.TRISC7 = 1;
    TRISCbits.TRISC6 = 0;
    LATCbits.LATC6 = 1;
    
    BaudRate.valor = 1666;
    
    BAUDCONbits.BRG16 = 1;
    TXSTAbits.BRGH = 1;
    SPBRG = BaudRate.bytes.byte0;
    SPBRGH = BaudRate.bytes.byte1;
    
    RCSTAbits.CREN = 1;       
    RCSTAbits.SPEN = 1;

    
    #if (Usart1_UsaInterrupcoes == Sim)
    PIE1bits.RCIE = 1;
    #endif
}


#if (Usart1_UsaInterrupcoes == Sim)
/*
 * Usart1_ServicoDeInterrupcao
 * Executa o servi�o de interrup��o do modulo
 */
void Usart1_ServicoDeInterrupcao (void)
{
    if ((PIE1bits.RCIE == 1) && (PIR1bits.RCIF == 1))
    {
        PIR1bits.RCIF = 0;
        
        Usart1_Rx(RCREG);
    }
}
#endif