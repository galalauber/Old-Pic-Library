/* 
 * Arquivo: Usart1.h
 * uC:      PIC18F46K22
 * Autor:   JABNeto
 * Data:    06.03.2017
 */

#ifndef USART1_H
#define	USART1_H

#include "Definicoes Gerais.h"
#include "Protocolo.h"


//Defini��es do m�dulo --------------------------------------------------------
#define Usart1_UsaInterrupcoes                          Sim
#define Usart1_PrioridadeDasInterrupcoes                Alta

#define Usart1_Rx(x)                                    Protocolo_Rx(x)
//#define Usart1_Tx()                                     Protocolo_Tx


//Estruturas do modulo---------------------------------------------------------





//Publica��o das fun��es do m�dulo --------------------------------------------
void Usart1_Inicializacao (void);


#if (Usart1_UsaInterrupcoes == Sim)
void Usart1_ServicoDeInterrupcao (void);
#endif 


//Publica��o das vari�veis do m�dulo ------------------------------------------



#endif	/* USART1_H */

